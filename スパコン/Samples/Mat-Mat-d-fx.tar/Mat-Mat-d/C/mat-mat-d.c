#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <mpi.h>

#define  N        384
#define  NPROCS   192

#define  DEBUG  1
#define  EPS    1.0e-18

double  A[N/NPROCS][N];
double  B[N][N/NPROCS];
double  C[N/NPROCS][N];

double  B_T[N][N/NPROCS];

int     myid, numprocs;

void MyMatMat(double C[N/NPROCS][N],
              double A[N/NPROCS][N], double B[N][N/NPROCS], int n); 

int main(int argc, char* argv[]) {

     double  t0, t1, t2, t_w;
     double  dc_inv, d_mflops;

     int     ierr;
     int     i, j;      
     int     iflag, iflag_t;

     ierr = MPI_Init(&argc, &argv);
     ierr = MPI_Comm_rank(MPI_COMM_WORLD, &myid);
     ierr = MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

     /* matrix generation --------------------------*/
     if (DEBUG == 1) {
       for(j=0; j<N/NPROCS; j++) {
         for(i=0; i<N; i++) {
           A[j][i] = 1.0;
           C[j][i] = 0.0;
         }
       }
       for(j=0; j<N; j++) {
         for(i=0; i<N/NPROCS; i++) {
           B[j][i] = 1.0;
         }
       }

     } else {
       srand(myid);
       dc_inv = 1.0/(double)RAND_MAX;
 
      for(j=0; j<N/NPROCS; j++) {
         for(i=0; i<N; i++) {
           A[j][i] = rand()*dc_inv;
           C[j][i] = 0.0;
         }
       }
      for(j=0; j<N; j++) {
         for(i=0; i<N/NPROCS; i++) {
           B[j][i] = rand()*dc_inv;
         }
       }

     } /* end of matrix generation --------------------------*/

     /* Start of mat-vec routine ----------------------------*/
     ierr = MPI_Barrier(MPI_COMM_WORLD);
     t1 = MPI_Wtime();

     MyMatMat(C, A, B, N);

     ierr = MPI_Barrier(MPI_COMM_WORLD);
     t2 = MPI_Wtime();
     t0 =  t2 - t1; 
     ierr = MPI_Reduce(&t0, &t_w, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
     /* End of mat-vec routine --------------------------- */

     if (myid == 0) {

       printf("N  = %d \n",N);
       printf("Mat-Mat time  = %lf [sec.] \n",t_w);

       d_mflops = 2.0*(double)N*(double)N*(double)N/t_w;
       d_mflops = d_mflops * 1.0e-6;
       printf(" %lf [MFLOPS] \n", d_mflops);
     }

     if (DEBUG == 1) {
       /* Verification routine ----------------- */
       iflag = 0;
       for(j=0; j<N/NPROCS; j++) { 
         for(i=0; i<N; i++) { 
           if (fabs(C[j][i] - (double)N) > EPS) {
             printf(" Error! in ( %d , %d )-th argument in PE %d \n",j, i, myid);
             iflag = 1;
             exit(1);
           } 
         }
       }
       /* ------------------------------------- */

       MPI_Reduce(&iflag, &iflag_t, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
       if (myid == 0) {
         if (iflag_t == 0) printf(" OK! \n");
       }

     }

     ierr = MPI_Finalize();

     exit(0);
}

void MyMatMat(double C[N/NPROCS][N], 
              double A[N/NPROCS][N], double B[N][N/NPROCS], int n) 
{
     int  i, j, k;
     int  ib;
   
     int  iloop; 
     int  jstart; 
     int  isendPE, irecvPE;
   
     MPI_Status istatus;

     /* Information of Send and recv PEs */
     isendPE = myid - 1;
     irecvPE = myid + 1;
     if (myid == 0) isendPE = numprocs - 1;
     if (myid == numprocs - 1) irecvPE = 0;   
    
     /* Block Length */
     ib = n/numprocs;

     /* Local Matrix-Matrix Multiplication -------------------  */
     /* This shoule be modified to finish parallelizing.        */
     for(i=0; i<ib; i++) {
       for(j=0; j<ib; j++) {
         for(k=0; k<n; k++) {
           C[i][j] += A[i][k] * B[k][j]; 
         }
       }
     }
     /* -----------------------------------------------------  */

}

