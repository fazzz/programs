#!/bin/bash
#PJM -L "rscgrp=lecture"
#PJM -L "node=1"
#PJM --mpi "proc=1"
#PJM -L "elapse=1:00"
mpirun ./mat-mat-noopt



