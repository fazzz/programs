#include <stdio.h>
#include <mpi.h>

#define N  500

double a[N];

int main(int argc, char* argv[]) {

     double  t1, t2, t0, t_w;
     double  d_c, d_sum;

     int     myid, numprocs;
     int     ierr;
     int     i, j, k;
     int     i_loop;      

     MPI_Status istatus;  
     MPI_Request irequest[192];


     ierr = MPI_Init(&argc, &argv);
     ierr = MPI_Comm_rank(MPI_COMM_WORLD, &myid);
     ierr = MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

     i_loop = 1;

     ierr = MPI_Barrier(MPI_COMM_WORLD);
     t1 = MPI_Wtime();


       /* Before Load */
       for (k=0; k<N; k++) {
         a[k] = (double)myid; 
       }
       for (i=0; i<myid*N; i++) {
          for (j=0; j<N; j++) {
             d_c = ((double)i+(double)j); 
             for (k=0; k<N; k++) {
                a[k] += a[k]*d_c; 
             }
          }
       } 

       /* Send data */   
       if (myid == 0) {
         for (i=0; i<N; i++) {
            a[i] = 3.14159265;
         }
         for (i=1; i<numprocs; i++) {
 
	    ierr = MPI_Isend(&a[0], N, MPI_DOUBLE, i, i_loop, 
            MPI_COMM_WORLD, &irequest[i]); 
          
	    /* ierr = MPI_Send(&a[0], N, MPI_DOUBLE, i, i_loop, 
	       MPI_COMM_WORLD); */  

         }
       } else {
         ierr = MPI_Recv(&a[0], N, MPI_DOUBLE, 0, i_loop, 
		       MPI_COMM_WORLD, &istatus);
       }

       /* After Load */
       for (i=0; i<(numprocs-myid)*N; i++) {
          for (j=0; j<N; j++) {
             d_c = ((double)i+(double)j); 
             for (k=0; k<N; k++) {
                a[k] += a[k]*d_c; 
             }
          }
       } 

       /* check to finish sending */
       if (myid == 0) {
          for (i=1; i<numprocs; i++) {
            ierr = MPI_Wait(&irequest[i], &istatus);
           }
        } 
      
     ierr = MPI_Barrier(MPI_COMM_WORLD);
     t2 = MPI_Wtime();
     t0 =  t2 - t1; 
 
     ierr = MPI_Reduce(&t0, &t_w, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

     if (myid == 0) {
       printf("  Execution time using MPI_Isend : %8.4lf  [sec.] \n", t_w);         
     }

     ierr = MPI_Finalize();

}
